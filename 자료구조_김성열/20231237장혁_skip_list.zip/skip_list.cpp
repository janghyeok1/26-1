#include <iostream>
#include <climits>
#include <string>
#include <sstream>
#include <vector>
using namespace std;

class SkipList {
    struct Node {
        int key;
        Node *up = nullptr, *down = nullptr, *left = nullptr, *right = nullptr;
        explicit Node(int k) : key(k) {}
    };
    Node* topLeft;
    Node* topRight;
    static constexpr int NEG_INF = INT_MIN;
    static constexpr int POS_INF = INT_MAX;
public:
    SkipList();
    ~SkipList();
    void insert(int key);
    bool search(int key) const;
    void print() const;
private:
    void buildInitial();
    Node* findPredecessor(int key) const;
};

SkipList::SkipList() {
    topLeft  = new Node(NEG_INF);
    topRight = new Node(POS_INF);
    topLeft->right = topRight;
    topRight->left = topLeft;
    buildInitial();
}

SkipList::~SkipList() {
    Node* row = topLeft;
    while (row) {
        Node* nextRow = row->down;
        Node* p = row;
        while (p) {
            Node* nxt = p->right;
            delete p;
            p = nxt;
        }
        row = nextRow;
    }
}

void SkipList::buildInitial() {
    int values[] = {0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60};
    for (int v : values) insert(v);
}

SkipList::Node* SkipList::findPredecessor(int key) const {
    Node* cur = topLeft;
    while(true) {
        while(cur->right->key <= key) cur = cur->right;
        if(cur->down) cur = cur->down;
        else break;
    }
    return cur;
}

bool SkipList::search(int key) const {
    int n = 0;
    for (Node* p = topLeft; p; p = p->down) ++n;
    Node* cur = topLeft;
    int lvl = n - 1;
    while (true) {
        while (cur->right->key <= key) cur = cur->right;
        cout << "L" << lvl << ": ";
        if(cur->key == NEG_INF) cout << "-INF";
        else if(cur->key == POS_INF) cout << "+INF";
        else cout << cur->key;
        if (cur->down) {
            cout << " / ";
            cur = cur->down;
            --lvl;
        }
        else {
            cout << '\n';
            break;
        }
    }
    return cur->key == key;
}

void SkipList::insert(int key) {
    Node* pred = findPredecessor(key);
    if (pred->key == key) {
        cout << "중복" << endl;
        return;
    }
    Node* nn = new Node(key);
    nn->left  = pred;
    nn->right = pred->right;
    pred->right->left = nn;
    pred->right = nn;

    Node* cur = nn;
    while (true) {
        Node* p = cur->left;
        while (!p->up && p->left)  p = p->left;
        Node* q = cur->right;
        while (!q->up && q->right) q = q->right;
        int count = 0;
        Node* mid = nullptr;
        for (Node* it = p->right; it != q; it = it->right) {
            ++count;
            if (count == 2) mid = it;
        }
        if (count <= 2) break;
        Node* upMid = new Node(mid->key);
        upMid->down = mid;
        mid->up = upMid;
        if (!p->up && !q->up) {
            Node* nl = new Node(NEG_INF);
            Node* nr = new Node(POS_INF);
            nl->right = upMid;  upMid->left = nl;
            upMid->right = nr;  nr->left = upMid;
            nl->down = topLeft;  topLeft->up  = nl;
            nr->down = topRight; topRight->up = nr;
            topLeft  = nl;
            topRight = nr;
            break;
        }
        Node* pu = p->up;
        Node* qu = q->up;
        upMid->left  = pu;
        upMid->right = qu;
        pu->right = upMid;
        qu->left  = upMid;
        cur = upMid;
    }
}

void SkipList::print() const {
    Node* bottom = topLeft;
    while (bottom->down) bottom = bottom->down;
    vector<int> keys;
    for (Node* p = bottom->right; p->right != nullptr; p = p->right) keys.push_back(p->key);
    int W = 0;
    for (int k : keys) {
        int w = (int)to_string(k).size();
        if (w > W) W = w;
    }
    W += 2;
    int n = 0;
    for (Node* p = topLeft; p; p = p->down) ++n;
    Node* row = topLeft;
    int lvl = n - 1;
    while (row) {
        vector<bool> present(keys.size(), false);
        for (Node* p = row->right; p->right != nullptr; p = p->right) {
            for (size_t i = 0; i < keys.size(); ++i) if (keys[i] == p->key) { present[i] = true; break; }
        }
        string label = "L" + to_string(lvl) + ":";
        string pad(label.size(), ' ');
        cout << label;
        for (size_t i = 0; i < keys.size(); ++i) {
            if (present[i]) {
                string s = to_string(keys[i]);
                cout << string(W - s.size(), ' ') << s;
            }
            else cout << string(W, ' ');
        }
        cout << endl;
        if (row->down) {
            cout << pad;
            for (size_t i = 0; i < keys.size(); ++i) {
                if (present[i])
                    cout << string(W - 1, ' ') << '|';
                else
                    cout << string(W, ' ');
            }
            cout << '\n';
        }
        row = row->down;
        --lvl;
    }
}

int main() {
    SkipList sl;
    sl.print();
    string line;
    while (true) {
        if (!getline(cin, line)) break;
        istringstream iss(line);
        string cmd;
        if (!(iss >> cmd)) continue;

        if (cmd == "insert") {
            int v;
            iss >> v;
            sl.insert(v);
            sl.print();
        }
        else if (cmd == "search") {
            int v;
            iss >> v;
            bool found = sl.search(v);
            cout << "search(" << v << ") = " << (found ? "Found" : "Not found") << endl;
        }
        else {
            cout << "알 수 없는 명령" << endl;
        }
    }
    return 0;
}