#include <iostream>
#include <stack>
#include <vector>
#include <string>
using namespace std;

const int M = 8;
const int N = 8;

char Map[M][N] = {
    {'0','1','1','1','1','1','1','1'},
    {'0','0','1','0','0','0','1','1'},
    {'1','0','1','0','1','0','1','1'},
    {'1','0','0','0','1','0','0','1'},
    {'1','1','1','0','1','1','0','1'},
    {'1','0','0','0','0','0','0','1'},
    {'1','0','1','1','1','0','1','1'},
    {'1','0','0','0','1','0','0','0'}
};

int di[] = {-1, 1, 0, 0};
int dj[] = { 0, 0,-1, 1};

void printMap(const string& title) {
    cout << "===== " << title << " =====" << endl;
    cout << endl;
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            cout << Map[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;
}

int Find() {
    stack<int> stk;
    int i = 0, j = 0;

    Map[i][j] = '*';
    int step = 1;
    cout << "===== 이동 내역 =====" << endl;
    cout << "step " << step++ << ": (" << i << ", " << j << ") 출발" << endl;

    while (1) {
        if (i == M-1 && j == N-1) {
            cout << "(" << M-1 << ", " << N-1 << ") 도착" << endl;
            return 1;
        }

        int ip = -100, jp = -100;
        for (int d = 0; d < 8; d++) {
            int ni = i + di[d];
            int nj = j + dj[d];
            if (ni >= 0 && ni < M && nj >= 0 && nj < N && Map[ni][nj] == '0') {
                ip = ni;
                jp = nj;
                break; 
            }
        }

        if (ip != -100) {
            stk.push(i);
            stk.push(j);
            i = ip;
            j = jp;
            Map[i][j] = '*';
            cout << "step " << step++ << ": (" << i << ", " << j << ") 전진" << endl;
        } else {
            if (stk.empty()) {
                cout << "[실패] 경로 없음" << endl;
                return -1;
            }
            Map[i][j] = 'X';
            cout << "step " << step++ << ": (" << i << ", " << j << ") 막힘" << endl;
            j = stk.top();
            stk.pop();
            i = stk.top();
            stk.pop();
            cout << "step " << step++ << ": (" << i << ", " << j << ") 복귀" << endl;
        }
    }
}

int main() {
    printMap("출발 전 미로");
    int result = Find();
    printMap("도착 후 미로");
    if (result == 1) cout << "결과: 경로를 찾았습니다!" << endl;
    else cout << "결과: 경로가 없습니다." << endl;
    return 0;
}